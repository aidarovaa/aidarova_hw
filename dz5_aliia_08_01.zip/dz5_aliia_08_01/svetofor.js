switch ("Зеленый"){
    case "Зеленый":
        console.log("Можно");
        break
    case "Желтый":
        console.log("Предупреждение");
        break
    case "Красный":
        console.log("Нельзя")
        break;
}