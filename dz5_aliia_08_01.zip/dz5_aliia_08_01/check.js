const array = [ 1, 2, 3 ]
const array_2 = [ 4, 5, 6 ]
const abc = array.length
const def = array_2.length
if (abc < def) {
    console.log("2 массив больше 1")
}else if (abc === def) {
    console.log("массивы равны")
}else {
    console.log("1 массив больше 2")
}
