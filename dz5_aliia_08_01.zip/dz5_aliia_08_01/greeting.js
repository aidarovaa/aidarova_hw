let firstName = prompt("Как Вас зовут?");
console.log("Привет " + firstName);