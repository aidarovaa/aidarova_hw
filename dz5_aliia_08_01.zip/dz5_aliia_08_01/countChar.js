const countChar = (mass) => {
    console.log('Длина аргумента: ' + mass.length + " символов");
}
let mass = prompt('Введите строку');

countChar (mass);